import MathOperations from "./t11";

const resultAdd = MathOperations.add(5, 3);
console.log(`Addition: ${resultAdd}`);

const resultMultiply = MathOperations.multiply(4, 6);
console.log(`Multiplication: ${resultMultiply}`);

// Addition: 8
// Multiplication: 24
