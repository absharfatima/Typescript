// Example usage
var arrayVariable = ["one", "two", "three"];
var nonArrayVariable = 42;
// Conditional assignment based on whether the variable is an array or not
var resultArray = ["result"];
var resultNonArray = 42;
// Verify the types
console.log(resultArray); // Output: ["result"]
console.log(resultNonArray); // Output: 42
