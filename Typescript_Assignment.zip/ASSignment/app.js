"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var t11_1 = require("./t11");
var resultAdd = t11_1.default.add(5, 3);
console.log("Addition: ".concat(resultAdd));
var resultMultiply = t11_1.default.multiply(4, 6);
console.log("Multiplication: ".concat(resultMultiply));
// Addition: 8
// Multiplication: 24
