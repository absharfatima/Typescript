// Example usage
var person1 = ["Rajesh Mishra", 25, "Cityland, Pune"];
// Accessing individual elements with a different variable name
var personName = person1[0];
var personAge = person1[1];
var personAddress = person1[2];
console.log(personName); // Output: Rajesh Mishra
console.log(personAge); // Output: 25
console.log(personAddress); // Output: Cityland, Pune
