// Example usage
var data = {
    person: {
        firstName: "John",
        lastName: "Doe",
        age: 30,
    },
    address: {
        street: "123 Main St",
        city: "Anytown",
        zipCode: "12345",
    },
    contactInfo: {
        email: "john@example.com",
        phone: "555-1234",
    },
};
console.log(data);
