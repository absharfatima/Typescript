// Example usage
var person = {
    firstName: "Johnson",
    lastName: "Deere",
    email: "johnson@gmail.com",
    phone: "8976453478"
};
console.log(person);
