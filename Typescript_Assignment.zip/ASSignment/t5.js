// Original variable of type any
var value = "Hello, TypeScript!";
// Type assertion to convert it to string
var stringValue = value;
// Now you can use it as a string
console.log(stringValue.length); // Output: 18
