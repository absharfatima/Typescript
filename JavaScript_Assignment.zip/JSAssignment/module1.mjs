// module1.js

// Importing functionality from addsubModule
import { addNumbers, subtractNumbers } from './addsubModule.mjs';

// Using the imported functions
const sum = addNumbers(5, 7);
console.log(`Sum: ${sum}`);

const product = subtractNumbers(3, 6);
console.log(`Subtract: ${product}`);
