// module3.mjs

// Importing named exports from calculator module
import { calculate } from './caculator.mjs';

// Using the imported function
const result = calculate(10, 5);
console.log('Result:', result);
