// addsubModule.js

// Exporting a function
export function addNumbers(a, b) {
    return a + b;
  }
  
  // Exporting another function
  export function subtractNumbers(a, b) {
    return a - b;
  }
  